exports.default = {
  type: 'monitoring',
  details: {
    title: 'courseApp',
    label: '',
    mainSection: 1,
    position: '1',
    id: 'courseApp',
    url: '/courseApp'
  },
  sections: [
    {
      details: {
        title: 'Data',
        label: 'Data',
        position: '1',
        id: 'Data_202501300632',
        readOnly: true,
        url: '/Data_202501300632',
        dataSource: {
          configs: [],
          Data_202501300632: {
            topics: [
              'liveValue.production.this.courseApp.0.runcounter.',
              'liveValue.production.this.courseApp.0.lastruntime.',
              'liveValue.production.this.courseApp.0.firstruntime.',
              'liveValue.production.this.courseApp.0.cpuusagecurrent.',
              'liveValue.production.this.courseApp.0.cpuusagemax.',
              'liveValue.production.this.courseApp.0.cpuusagemin.',
              'liveValue.production.this.courseApp.0.memoryusagecurrent.',
              'liveValue.production.this.courseApp.0.memoryusagemax.',
              'liveValue.production.this.courseApp.0.memoryusagemin.',
              'liveValue.production.this.courseApp.0.temperature.'
            ],
          },
        },
      },
      content: [
        {
          id: 'Data_202501300632',
          title: 'Data',
          layout: [
            {
              Group1_202501300632: { xs: 12 },
              Group2_202501300632: { xs: 12 },
              Group3_202501300632: { xs: 12 },
              Group4_202501300632: { xs: 12 },
            },
          ],
          ui: {
            Group1_202501300632: {
              type: 'groupBox',
              title: 'Runtime',
              children: {
                layout: [
                  {
                    'liveValue.production.this.courseApp.0.runcounter': { xs: 2 },
                    'liveValue.production.this.courseApp.0.lastruntime': { xs: 2 },
                    'liveValue.production.this.courseApp.0.firstruntime': { xs: 2 }
                  }
                ],
                ui: [
                  {
                    'liveValue.production.this.courseApp.0.runcounter': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Run Counter',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.courseApp.0.runcounter.']
                    }
                  },
                  {
                    'liveValue.production.this.courseApp.0.lastruntime': {
                      type: 'text',
                      placeholder: '',
                      title: 'Last Run Time',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.courseApp.0.lastruntime.']
                    }
                  },
                  {
                    'liveValue.production.this.courseApp.0.firstruntime': {
                      type: 'text',
                      placeholder: '',
                      title: 'First Run Time',
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.courseApp.0.firstruntime.']
                    }
                  }
                ]
              }
            },
            Group2_202501300632: {
              type: 'groupBox',
              title: 'Results CPU',
              children: {
                layout: [
                  {
                    'liveValue.production.this.courseApp.0.cpuusagecurrent': { xs: 3 },
                    'liveValue.production.this.courseApp.0.cpuusagemax': { xs: 3 },
                    'liveValue.production.this.courseApp.0.cpuusagemin': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'liveValue.production.this.courseApp.0.cpuusagecurrent': {
                      type: 'horizontalChart',
                      dataType: 'float',
                      title: 'Cpu Usage Current',
                      showControls: false,
                      readOnly: true,
                      chartDefinitions: {
                        data: 0,
                        minValue: 0,
                        maxValue: 100,
                        units: '',
                        decimals: 3
                      },
                      tagsRelated: ['liveValue.production.this.courseApp.0.cpuusagecurrent.']
                    }
                  },
                  {
                    'liveValue.production.this.courseApp.0.cpuusagemax': {
                      type: 'horizontalChart',
                      dataType: 'float',
                      title: 'Cpu Usage Max',
                      showControls: false,
                      readOnly: true,
                      chartDefinitions: {
                        data: 0,
                        minValue: 0,
                        maxValue: 100,
                        units: '',
                        decimals: 3
                      },
                      tagsRelated: ['liveValue.production.this.courseApp.0.cpuusagemax.']
                    }
                  },
                  {
                    'liveValue.production.this.courseApp.0.cpuusagemin': {
                      type: 'horizontalChart',
                      dataType: 'float',
                      title: 'Cpu Usage Min',
                      showControls: false,
                      readOnly: true,
                      chartDefinitions: {
                        data: 0,
                        minValue: 0,
                        maxValue: 100,
                        units: '',
                        decimals: 3
                      },
                      tagsRelated: ['liveValue.production.this.courseApp.0.cpuusagemin.']
                    }
                  }
                ]
              }
            },
            Group3_202501300632: {
              type: 'groupBox',
              title: 'Results Memory',
              children: {
                layout: [
                  {
                    'liveValue.production.this.courseApp.0.memoryusagecurrent': { xs: 3 },
                    'liveValue.production.this.courseApp.0.memoryusagemax': { xs: 3 },
                    'liveValue.production.this.courseApp.0.memoryusagemin': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'liveValue.production.this.courseApp.0.memoryusagecurrent': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Memory Usage Current',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.courseApp.0.memoryusagecurrent.']
                    }
                  },
                  {
                    'liveValue.production.this.courseApp.0.memoryusagemax': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Memory Usage Max',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.courseApp.0.memoryusagemax.']
                    }
                  },
                  {
                    'liveValue.production.this.courseApp.0.memoryusagemin': {
                      type: 'textInput',
                      dataType: 'integer',
                      title: 'Memory Usage Min',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.courseApp.0.memoryusagemin.']
                    }
                  }
                ]
              }
            },
            Group4_202501300632: {
              type: 'groupBox',
              title: 'Results Temp',
              children: {
                layout: [
                  {
                    'liveValue.production.this.courseApp.0.temperature': { xs: 3 }
                  }
                ],
                ui: [
                  {
                    'liveValue.production.this.courseApp.0.temperature': {
                      type: 'textInput',
                      dataType: 'float',
                      title: 'Temperature',
                      showControls: false,
                      readOnly: true,
                      tagsRelated: ['liveValue.production.this.courseApp.0.temperature.'],
                      unitConversion: {
                        category: 'TEMP.K',
                        showUnits: true,
                      }
                    }
                  }
                ]
              }
            }
          }
        }
      ]
    }
  ]
}
