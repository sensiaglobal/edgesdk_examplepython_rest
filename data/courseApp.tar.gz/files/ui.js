exports.default = {
  type: 'application',
  details: {
    title: 'courseApp',
    label: '',
    mainSection: 1,
    position: '1',
    id: 'courseApp',
    url: '/courseApp'
  },
  sections: [
    {
      details: {
        title: 'Configuration',
        label: 'Configuration',
        position: '1',
        id: 'Configuration_202501300632',
        url: '/Configuration_202501300632'
      },
      content: [
        {
          id: 'Configuration_202501300632',
          title: 'Configuration',
          layout: [
            {
              Group1_202501300632: { xs: 12 },
            },
          ],
          ui: {
            Group1_202501300632: {
              type: 'groupBox',
              title: '',
              children: {
                layout: [
                  {
                    'configrunningperiod': { xs: 2 },
                    'maxminrestartperiod': { xs: 2 }
                  }
                ],
                ui: [
                  {
                    'configrunningperiod': {
                      type: 'textInput',
                      dataType: 'integer',
                      min: 1,
                      max: 100,
                      title: 'Config Running Period',
                      showControls: false,
                      readOnly: false,
                      tagsRelated: ['configrunningperiod.']
                    }
                  },
                  {
                    'maxminrestartperiod': {
                      type: 'textInput',
                      dataType: 'integer',
                      min: 1,
                      max: 59,
                      title: 'Max Min Restart Period',
                      showControls: false,
                      readOnly: false,
                      tagsRelated: ['maxminrestartperiod.']
                    }
                  }
                ]
              }
            }
          }
        }
      ]
    }
  ]
}
